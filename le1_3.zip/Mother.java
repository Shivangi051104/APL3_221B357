public class Mother{
    static void show(){
        System.out.println("Hello World");
    }
}

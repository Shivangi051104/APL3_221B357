class Mother1 {
    void show() {
        System.out.println("Mother1: Non-static show()");
    }
}
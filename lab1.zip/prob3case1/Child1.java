class Child1 extends Mother1 {

    void show() {
        System.out.println("Child1: Non-static show()");
    }
}
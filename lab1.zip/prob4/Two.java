class Two extends One {
    Two(int x) {
        super(x); 
        System.out.println("Two's constructor called with value: " + x);
    }
}

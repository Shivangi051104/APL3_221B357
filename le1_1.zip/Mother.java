public class Mother {
    int x = 10;

    void show() {
        System.out.println("This is the show() method of Mother class.Value of x: " + x);
    }
}
